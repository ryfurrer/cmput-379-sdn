#ifndef _UTIL_
#define _UTIL_

#include <string>

using namespace std;

void trimWhitespace(string & cmd);

#endif